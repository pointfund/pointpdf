# AflacAOCAmount.rb
'Guarantee of Payment Obligations'

lineA = 'In consideration of Point Funding, L.L.C. (“Lender”) extending credit to
(“Borrower”), the undersigned (“Guarantor”,
which term means individually, collectively and interchangeable any, each and/or
all of them if more than one) jointly, severally and solidarily, if more than one
Guarantor, unconditionally guarantees to Lender, the prompt payment in full when
due, whether by acceleration or otherwise, of any and all indebtedness, obligations
and liabilities of any kind of Borrower including, without limitation, principal,
interest, fees, or costs payable pursuant to that certain Promissory Note, issued by
Borrower to Lender on (as may be amended, modified,
supplemented or restated from time to time, the “Note”).'