module DisplayBookContracts
	class ShowBookContracts  
		def this_method
			puts "hello"
		end
	end
	def this_method
		puts "hello  but No"
	end
end
