module ContractsHelper
end
