module GuideHelper
end
