class Record < ApplicationRecord
end
