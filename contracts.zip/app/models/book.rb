class Book < ApplicationRecord
	has_many :contracts
end
