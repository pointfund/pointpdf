class PageLayout < ApplicationRecord
	belongs_to :contract
	
end
