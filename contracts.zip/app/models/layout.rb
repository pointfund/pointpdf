class Layout < ApplicationRecord
	belongs_to :page_part
	belongs_to :contract
end
