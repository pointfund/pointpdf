class VariableList < ApplicationRecord
end
