require 'test_helper'

class PageLayoutTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
