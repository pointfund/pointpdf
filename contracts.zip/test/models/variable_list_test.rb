require 'test_helper'

class VariableListTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
