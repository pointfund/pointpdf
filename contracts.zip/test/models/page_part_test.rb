require 'test_helper'

class PagePartTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
