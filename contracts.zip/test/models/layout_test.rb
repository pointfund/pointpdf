require 'test_helper'

class LayoutTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
